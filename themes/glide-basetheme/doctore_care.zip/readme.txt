=== BaseTheme Package ===

Contributors: Abu Bakar
Tags: custom-menu, full-width-template, theme-options, translation-ready
Requires at least: 5.8
Tested up to: 5.8
Stable tag: 1.0.0

A BaseTheme Package WordPress theme

== Description ==

This is a BaseTheme Package WordPress theme
