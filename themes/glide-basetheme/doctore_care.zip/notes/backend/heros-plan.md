
# Heros Plan

Description for this file goes here

-------------------------------------------------------

### Homepage

* [ ] Title
* [ ] Featured Image
* [ ] Intro Text

### Wind Energy

* [ ] Title
* [ ] Image
* [ ] First Button (Message)
  * [ ] Icon
  * [ ] Heading
  * [ ] Hash ID
