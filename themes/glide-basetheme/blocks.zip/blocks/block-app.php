<?php
/**
 * Block Name: Image Alongside Text
 *
 * The template for displaying the custom gutenberg block named Image Alongside Text.
 *
 * @link https://www.advancedcustomfields.com/resources/blocks/
 *
 * @package BaseTheme Package
 * @since 1.0.0
 */


// Get all the fields from ACF for this block ID

$block_fields = get_fields_escaped( $block['id'] );
// $block_fields = get_fields_escaped( $block['id'] ,'sanitize_text_field' ); // if want to remove all html


// Set the block name for it's ID & class from it's file name
$block_glide_name = $block['name'];
$block_glide_name = str_replace( 'acf/', '', $block_glide_name );

// Set the preview thumbnail for this block for gutenberg editor view.
if ( isset( $block['data']['preview_image_help'] ) ) {    /* rendering in inserter preview  */
	echo '<img src="' . $block['data']['preview_image_help'] . '" style="width:100%; height:auto;">';
}

// create align class ("alignwide") from block setting ("wide").
$align_class = $block['align'] ? 'align' . $block['align'] : '';

// Get the class name for the block to be used for it.
$class_name = ( isset( $block['className'] ) ) ? $block['className'] : null;

// Making the unique ID for the block.
$id = 'block-' . $block_glide_name . '-' . $block['id'];

// Making the unique ID for the block.
if ( $block['name'] ) {
	$block_name = $block['name'];
	$block_name = str_replace( '/', '-', $block_name );
	$name       = 'block-' . $block_name;
}

//    echo '<pre>';
//   print_r($block_fields);
//    echo '</pre>';
$app_sub_title = ( isset( $block_fields['app_sub_title'] ) ) ? $block_fields['app_sub_title'] : null;
$app_main_title = ( isset( $block_fields['app_main_title'] ) ) ? $block_fields['app_main_title'] : null;
$app_description = ( isset( $block_fields['app_description'] ) ) ? $block_fields['app_description'] : null;
$app_pre_img = ( isset( $block_fields['app_pre_img'] ) ) ? $block_fields['app_pre_img'] : null;
$app_feature = ( isset( $block_fields['app_feature'] ) ) ? $block_fields['app_feature'] : null;

?>
<div id="<?php echo $id; ?>" class="<?php echo $align_class . ' ' . $class_name . ' ' . $name; ?> glide-block-<?php echo $block_glide_name; ?>">

	<section class="care-app">
				<div class="container">
					<div class="row-block">
						<div class="col-block-6">
							<div class="textbox">
								<h4><?php echo html_entity_decode($app_sub_title) ;?></h4>
								<h2><?php echo html_entity_decode($app_main_title) ;?></h2>
								<?php echo html_entity_decode($app_description) ;?>

								<ul class="features-holder">
<?php  
						foreach ($app_feature as $row) {
							?>
									<li>
										<div class="feature-box">
											<div class="icon-holder">
												<img src="<?php echo $row['app_inner_img'];?>" alt="icon">
											</div>
											<h5><?php echo html_entity_decode($row['app_inner_title']) ;?></h5>
										</div>
									</li>
									<?php 
						} 
					?>
								</ul>
							</div>
						</div>
						<div class="col-block-6">
							<div class="image-holder">
								<img src="<?php echo $app_pre_img;?>" alt="">
							</div>
						</div>
					</div>
				</div>
			</section>

</div>
